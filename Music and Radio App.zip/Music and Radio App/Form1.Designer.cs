﻿namespace Music_and_Radio_App
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button25 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button32 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
            this.player = new AxWMPLib.AxWindowsMediaPlayer();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player)).BeginInit();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.panel1.Controls.Add(this.linkLabel1);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button12);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button11);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Location = new System.Drawing.Point(0, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(204, 550);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.listBox2);
            this.panel6.Controls.Add(this.listBox1);
            this.panel6.Controls.Add(this.button25);
            this.panel6.Controls.Add(this.button24);
            this.panel6.Controls.Add(this.button23);
            this.panel6.Location = new System.Drawing.Point(205, 67);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1022, 460);
            this.panel6.TabIndex = 5;
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(575, 181);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(40, 17);
            this.listBox2.TabIndex = 34;
            this.listBox2.Visible = false;
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.listBox1.Font = new System.Drawing.Font("SimSun", 12.75F);
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 17;
            this.listBox1.Location = new System.Drawing.Point(6, 181);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(609, 276);
            this.listBox1.TabIndex = 33;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.Transparent;
            this.button25.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.add_song;
            this.button25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button25.FlatAppearance.BorderSize = 0;
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.ForeColor = System.Drawing.Color.Black;
            this.button25.Location = new System.Drawing.Point(575, 135);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(40, 40);
            this.button25.TabIndex = 32;
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.DodgerBlue;
            this.button24.FlatAppearance.BorderSize = 0;
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.ForeColor = System.Drawing.Color.Black;
            this.button24.Location = new System.Drawing.Point(122, 14);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(101, 34);
            this.button24.TabIndex = 2;
            this.button24.Text = "Radio";
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.Transparent;
            this.button23.FlatAppearance.BorderSize = 0;
            this.button23.Location = new System.Drawing.Point(22, 14);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(101, 34);
            this.button23.TabIndex = 1;
            this.button23.Text = "Songs";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.label22);
            this.panel8.Controls.Add(this.label23);
            this.panel8.Controls.Add(this.label24);
            this.panel8.Controls.Add(this.label25);
            this.panel8.Controls.Add(this.label26);
            this.panel8.Controls.Add(this.button45);
            this.panel8.Controls.Add(this.button46);
            this.panel8.Controls.Add(this.button47);
            this.panel8.Controls.Add(this.button48);
            this.panel8.Controls.Add(this.button49);
            this.panel8.Controls.Add(this.label17);
            this.panel8.Controls.Add(this.label18);
            this.panel8.Controls.Add(this.label19);
            this.panel8.Controls.Add(this.label20);
            this.panel8.Controls.Add(this.label21);
            this.panel8.Controls.Add(this.button40);
            this.panel8.Controls.Add(this.button41);
            this.panel8.Controls.Add(this.button42);
            this.panel8.Controls.Add(this.button43);
            this.panel8.Controls.Add(this.button44);
            this.panel8.Controls.Add(this.label12);
            this.panel8.Controls.Add(this.label13);
            this.panel8.Controls.Add(this.label14);
            this.panel8.Controls.Add(this.label15);
            this.panel8.Controls.Add(this.label16);
            this.panel8.Controls.Add(this.button35);
            this.panel8.Controls.Add(this.button36);
            this.panel8.Controls.Add(this.button37);
            this.panel8.Controls.Add(this.button38);
            this.panel8.Controls.Add(this.button39);
            this.panel8.Controls.Add(this.label8);
            this.panel8.Controls.Add(this.label7);
            this.panel8.Controls.Add(this.label6);
            this.panel8.Controls.Add(this.label5);
            this.panel8.Controls.Add(this.label3);
            this.panel8.Controls.Add(this.button32);
            this.panel8.Controls.Add(this.button31);
            this.panel8.Controls.Add(this.button30);
            this.panel8.Controls.Add(this.button29);
            this.panel8.Controls.Add(this.button28);
            this.panel8.Controls.Add(this.button26);
            this.panel8.Controls.Add(this.button27);
            this.panel8.Location = new System.Drawing.Point(205, 67);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1022, 476);
            this.panel8.TabIndex = 35;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label22.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label22.Location = new System.Drawing.Point(745, 356);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(138, 22);
            this.label22.TabIndex = 72;
            this.label22.Text = "NO1 Türk 90\'lar";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label23.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label23.Location = new System.Drawing.Point(745, 296);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(88, 22);
            this.label23.TabIndex = 71;
            this.label23.Text = "ÜLKÜ FM";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label24.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label24.Location = new System.Drawing.Point(745, 237);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(114, 22);
            this.label24.TabIndex = 70;
            this.label24.Text = "Türkü Radyo";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label25.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label25.Location = new System.Drawing.Point(745, 177);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(104, 22);
            this.label25.TabIndex = 69;
            this.label25.Text = "NTV Radyo";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label26.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label26.Location = new System.Drawing.Point(745, 113);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(91, 22);
            this.label26.TabIndex = 68;
            this.label26.Text = "CNN Türk";
            // 
            // button45
            // 
            this.button45.BackColor = System.Drawing.Color.Transparent;
            this.button45.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.play__7_;
            this.button45.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button45.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button45.FlatAppearance.BorderSize = 0;
            this.button45.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button45.ForeColor = System.Drawing.Color.Black;
            this.button45.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button45.Location = new System.Drawing.Point(684, 342);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(40, 40);
            this.button45.TabIndex = 67;
            this.button45.UseVisualStyleBackColor = true;
            this.button45.Click += new System.EventHandler(this.button45_Click);
            // 
            // button46
            // 
            this.button46.BackColor = System.Drawing.Color.Transparent;
            this.button46.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.play__7_;
            this.button46.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button46.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button46.FlatAppearance.BorderSize = 0;
            this.button46.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button46.ForeColor = System.Drawing.Color.Black;
            this.button46.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button46.Location = new System.Drawing.Point(684, 282);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(40, 40);
            this.button46.TabIndex = 66;
            this.button46.UseVisualStyleBackColor = true;
            this.button46.Click += new System.EventHandler(this.button46_Click);
            // 
            // button47
            // 
            this.button47.BackColor = System.Drawing.Color.Transparent;
            this.button47.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.play__7_;
            this.button47.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button47.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button47.FlatAppearance.BorderSize = 0;
            this.button47.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button47.ForeColor = System.Drawing.Color.Black;
            this.button47.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button47.Location = new System.Drawing.Point(684, 223);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(40, 40);
            this.button47.TabIndex = 65;
            this.button47.UseVisualStyleBackColor = true;
            this.button47.Click += new System.EventHandler(this.button47_Click);
            // 
            // button48
            // 
            this.button48.BackColor = System.Drawing.Color.Transparent;
            this.button48.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.play__7_;
            this.button48.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button48.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button48.FlatAppearance.BorderSize = 0;
            this.button48.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button48.ForeColor = System.Drawing.Color.Black;
            this.button48.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button48.Location = new System.Drawing.Point(684, 158);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(40, 40);
            this.button48.TabIndex = 64;
            this.button48.UseVisualStyleBackColor = true;
            this.button48.Click += new System.EventHandler(this.button48_Click);
            // 
            // button49
            // 
            this.button49.BackColor = System.Drawing.Color.Transparent;
            this.button49.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.play__7_;
            this.button49.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button49.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button49.FlatAppearance.BorderSize = 0;
            this.button49.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button49.ForeColor = System.Drawing.Color.Black;
            this.button49.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button49.Location = new System.Drawing.Point(684, 99);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(40, 40);
            this.button49.TabIndex = 63;
            this.button49.UseVisualStyleBackColor = true;
            this.button49.Click += new System.EventHandler(this.button49_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label17.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label17.Location = new System.Drawing.Point(538, 353);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(117, 22);
            this.label17.TabIndex = 62;
            this.label17.Text = "Radyo Sinerji";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label18.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label18.Location = new System.Drawing.Point(538, 293);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(132, 22);
            this.label18.TabIndex = 61;
            this.label18.Text = "Karadeniz Türk";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label19.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label19.Location = new System.Drawing.Point(538, 234);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(120, 22);
            this.label19.TabIndex = 60;
            this.label19.Text = "Konya Tiryaki";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label20.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label20.Location = new System.Drawing.Point(538, 174);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(142, 22);
            this.label20.TabIndex = 59;
            this.label20.Text = "Radyo Fenomen";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label21.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label21.Location = new System.Drawing.Point(538, 110);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(89, 22);
            this.label21.TabIndex = 58;
            this.label21.Text = "RADYO 7";
            // 
            // button40
            // 
            this.button40.BackColor = System.Drawing.Color.Transparent;
            this.button40.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.play__7_;
            this.button40.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button40.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button40.FlatAppearance.BorderSize = 0;
            this.button40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button40.ForeColor = System.Drawing.Color.Black;
            this.button40.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button40.Location = new System.Drawing.Point(477, 339);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(40, 40);
            this.button40.TabIndex = 57;
            this.button40.UseVisualStyleBackColor = true;
            this.button40.Click += new System.EventHandler(this.button40_Click);
            // 
            // button41
            // 
            this.button41.BackColor = System.Drawing.Color.Transparent;
            this.button41.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.play__7_;
            this.button41.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button41.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button41.FlatAppearance.BorderSize = 0;
            this.button41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button41.ForeColor = System.Drawing.Color.Black;
            this.button41.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button41.Location = new System.Drawing.Point(477, 279);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(40, 40);
            this.button41.TabIndex = 56;
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Click += new System.EventHandler(this.button41_Click);
            // 
            // button42
            // 
            this.button42.BackColor = System.Drawing.Color.Transparent;
            this.button42.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.play__7_;
            this.button42.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button42.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button42.FlatAppearance.BorderSize = 0;
            this.button42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button42.ForeColor = System.Drawing.Color.Black;
            this.button42.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button42.Location = new System.Drawing.Point(477, 220);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(40, 40);
            this.button42.TabIndex = 55;
            this.button42.UseVisualStyleBackColor = true;
            this.button42.Click += new System.EventHandler(this.button42_Click);
            // 
            // button43
            // 
            this.button43.BackColor = System.Drawing.Color.Transparent;
            this.button43.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.play__7_;
            this.button43.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button43.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button43.FlatAppearance.BorderSize = 0;
            this.button43.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button43.ForeColor = System.Drawing.Color.Black;
            this.button43.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button43.Location = new System.Drawing.Point(477, 155);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(40, 40);
            this.button43.TabIndex = 54;
            this.button43.UseVisualStyleBackColor = true;
            this.button43.Click += new System.EventHandler(this.button43_Click);
            // 
            // button44
            // 
            this.button44.BackColor = System.Drawing.Color.Transparent;
            this.button44.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.play__7_;
            this.button44.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button44.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button44.FlatAppearance.BorderSize = 0;
            this.button44.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button44.ForeColor = System.Drawing.Color.Black;
            this.button44.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button44.Location = new System.Drawing.Point(477, 96);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(40, 40);
            this.button44.TabIndex = 53;
            this.button44.UseVisualStyleBackColor = true;
            this.button44.Click += new System.EventHandler(this.button44_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label12.Location = new System.Drawing.Point(321, 353);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(105, 22);
            this.label12.TabIndex = 52;
            this.label12.Text = "SLOW Turk";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label13.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label13.Location = new System.Drawing.Point(321, 293);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(105, 22);
            this.label13.TabIndex = 51;
            this.label13.Text = "METRO FM";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label14.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label14.Location = new System.Drawing.Point(321, 234);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(88, 22);
            this.label14.TabIndex = 50;
            this.label14.Text = "BEST FM";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label15.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label15.Location = new System.Drawing.Point(321, 174);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(99, 22);
            this.label15.TabIndex = 49;
            this.label15.Text = "Nostalji FM";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label16.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label16.Location = new System.Drawing.Point(321, 110);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(100, 22);
            this.label16.TabIndex = 48;
            this.label16.Text = "JOY TURK";
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.Color.Transparent;
            this.button35.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.play__7_;
            this.button35.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button35.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button35.FlatAppearance.BorderSize = 0;
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button35.ForeColor = System.Drawing.Color.Black;
            this.button35.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button35.Location = new System.Drawing.Point(260, 339);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(40, 40);
            this.button35.TabIndex = 47;
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.Color.Transparent;
            this.button36.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.play__7_;
            this.button36.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button36.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button36.FlatAppearance.BorderSize = 0;
            this.button36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button36.ForeColor = System.Drawing.Color.Black;
            this.button36.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button36.Location = new System.Drawing.Point(260, 279);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(40, 40);
            this.button36.TabIndex = 46;
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // button37
            // 
            this.button37.BackColor = System.Drawing.Color.Transparent;
            this.button37.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.play__7_;
            this.button37.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button37.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button37.FlatAppearance.BorderSize = 0;
            this.button37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button37.ForeColor = System.Drawing.Color.Black;
            this.button37.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button37.Location = new System.Drawing.Point(260, 220);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(40, 40);
            this.button37.TabIndex = 45;
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // button38
            // 
            this.button38.BackColor = System.Drawing.Color.Transparent;
            this.button38.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.play__7_;
            this.button38.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button38.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button38.FlatAppearance.BorderSize = 0;
            this.button38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button38.ForeColor = System.Drawing.Color.Black;
            this.button38.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button38.Location = new System.Drawing.Point(260, 155);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(40, 40);
            this.button38.TabIndex = 44;
            this.button38.UseVisualStyleBackColor = true;
            this.button38.Click += new System.EventHandler(this.button38_Click);
            // 
            // button39
            // 
            this.button39.BackColor = System.Drawing.Color.Transparent;
            this.button39.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.play__7_;
            this.button39.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button39.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button39.FlatAppearance.BorderSize = 0;
            this.button39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button39.ForeColor = System.Drawing.Color.Black;
            this.button39.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button39.Location = new System.Drawing.Point(260, 96);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(40, 40);
            this.button39.TabIndex = 43;
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label8.Location = new System.Drawing.Point(83, 348);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(127, 22);
            this.label8.TabIndex = 41;
            this.label8.Text = "VIRGIN Radyo";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label7.Location = new System.Drawing.Point(83, 288);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 22);
            this.label7.TabIndex = 40;
            this.label7.Text = "90\'lar";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(83, 229);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 22);
            this.label6.TabIndex = 39;
            this.label6.Text = "Kral Pop";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(83, 169);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 22);
            this.label5.TabIndex = 38;
            this.label5.Text = "Kral FM";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(83, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 22);
            this.label3.TabIndex = 37;
            this.label3.Text = "İstanbul FM";
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.Color.Transparent;
            this.button32.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.play__7_;
            this.button32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button32.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button32.FlatAppearance.BorderSize = 0;
            this.button32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button32.ForeColor = System.Drawing.Color.Black;
            this.button32.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button32.Location = new System.Drawing.Point(22, 334);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(40, 40);
            this.button32.TabIndex = 36;
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.Transparent;
            this.button31.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.play__7_;
            this.button31.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button31.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button31.FlatAppearance.BorderSize = 0;
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button31.ForeColor = System.Drawing.Color.Black;
            this.button31.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button31.Location = new System.Drawing.Point(22, 274);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(40, 40);
            this.button31.TabIndex = 35;
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.Transparent;
            this.button30.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.play__7_;
            this.button30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button30.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button30.FlatAppearance.BorderSize = 0;
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button30.ForeColor = System.Drawing.Color.Black;
            this.button30.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button30.Location = new System.Drawing.Point(22, 215);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(40, 40);
            this.button30.TabIndex = 34;
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.Transparent;
            this.button29.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.play__7_;
            this.button29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button29.FlatAppearance.BorderSize = 0;
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button29.ForeColor = System.Drawing.Color.Black;
            this.button29.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button29.Location = new System.Drawing.Point(22, 150);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(40, 40);
            this.button29.TabIndex = 33;
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.Transparent;
            this.button28.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.play__7_;
            this.button28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button28.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button28.FlatAppearance.BorderSize = 0;
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button28.ForeColor = System.Drawing.Color.Black;
            this.button28.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button28.Location = new System.Drawing.Point(22, 91);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(40, 40);
            this.button28.TabIndex = 32;
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.DodgerBlue;
            this.button26.FlatAppearance.BorderSize = 0;
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.ForeColor = System.Drawing.Color.Black;
            this.button26.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button26.Location = new System.Drawing.Point(22, 21);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(101, 34);
            this.button26.TabIndex = 4;
            this.button26.Text = "Songs";
            this.button26.UseVisualStyleBackColor = false;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.Transparent;
            this.button27.FlatAppearance.BorderSize = 0;
            this.button27.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button27.Location = new System.Drawing.Point(122, 21);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(101, 34);
            this.button27.TabIndex = 3;
            this.button27.Text = "Radio";
            this.button27.UseVisualStyleBackColor = false;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel1.Location = new System.Drawing.Point(71, 70);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(58, 13);
            this.linkLabel1.TabIndex = 31;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "About me?";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.instagram_new;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(12, 13);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(54, 54);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.twitter;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(72, 13);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(54, 54);
            this.button2.TabIndex = 10;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button12
            // 
            this.button12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button12.FlatAppearance.BorderSize = 0;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("MV Boli", 10F);
            this.button12.Location = new System.Drawing.Point(58, 228);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(135, 32);
            this.button12.TabIndex = 25;
            this.button12.Text = "Songs And Radio\r\n";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.github;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Location = new System.Drawing.Point(132, 13);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(54, 54);
            this.button3.TabIndex = 11;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button11
            // 
            this.button11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button11.FlatAppearance.BorderSize = 0;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("MV Boli", 10F);
            this.button11.Location = new System.Drawing.Point(58, 184);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(116, 38);
            this.button11.TabIndex = 24;
            this.button11.Text = "Main Menu";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Transparent;
            this.button5.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.search;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button5.Enabled = false;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ForeColor = System.Drawing.Color.Black;
            this.button5.Location = new System.Drawing.Point(12, 220);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(40, 40);
            this.button5.TabIndex = 20;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Visible = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.BackgroundImage = global::Music_and_Radio_App.Properties.Resources.top_menu;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.Enabled = false;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.Color.Black;
            this.button4.Location = new System.Drawing.Point(12, 174);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(40, 40);
            this.button4.TabIndex = 19;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Silver;
            this.panel3.Location = new System.Drawing.Point(32, 178);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1, 70);
            this.panel3.TabIndex = 3;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Indigo;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(0, 549);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1227, 45);
            this.panel2.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.Gainsboro;
            this.label2.Location = new System.Drawing.Point(530, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(189, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Developed By Salih Baki Ayrancı 2022";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Gainsboro;
            this.panel4.Controls.Add(this.label1);
            this.panel4.Location = new System.Drawing.Point(202, -1);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1025, 67);
            this.panel4.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(14, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "No Playing...";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Multiselect = true;
            // 
            // fileSystemWatcher1
            // 
            this.fileSystemWatcher1.EnableRaisingEvents = true;
            this.fileSystemWatcher1.SynchronizingObject = this;
            // 
            // player
            // 
            this.player.Enabled = true;
            this.player.Location = new System.Drawing.Point(0, 0);
            this.player.Name = "player";
            this.player.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("player.OcxState")));
            this.player.Size = new System.Drawing.Size(1019, 482);
            this.player.TabIndex = 0;
            this.player.PlayStateChange += new AxWMPLib._WMPOCXEvents_PlayStateChangeEventHandler(this.player_PlayStateChange);
            this.player.Enter += new System.EventHandler(this.player_Enter);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.player);
            this.panel5.Location = new System.Drawing.Point(205, 67);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1019, 482);
            this.panel5.TabIndex = 36;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1227, 594);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player)).EndInit();
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label2;
        private System.IO.FileSystemWatcher fileSystemWatcher1;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private AxWMPLib.AxWindowsMediaPlayer player;
        private System.Windows.Forms.Panel panel5;
    }
}

