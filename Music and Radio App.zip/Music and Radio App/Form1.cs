﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Net.Sockets;


namespace Music_and_Radio_App
{
   
    
    
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
            
        }

        


        private void tabPage8_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_TabIndexChanged(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
            button4.Visible = true;
            button5.Visible = false;
            panel6.Visible = false;
            panel8.Visible = false;
            panel5.Visible = true;
            
            
            
            panel6.Visible = true;
                
        }

        private void button12_Click(object sender, EventArgs e)
        {
            button4.Visible = false;
            button5.Visible = true;
            label1.Text = player.status;

            panel5.Visible = false;
            panel6.Visible = true;
            panel8.Visible = false;
            
        }

        private void button13_Click(object sender, EventArgs e)
        {
            button4.Visible = false;
            button5.Visible = false;
            
            
        }

        private void button14_Click(object sender, EventArgs e)
        {
            button4.Visible = false;
            button5.Visible = false;
            label1.Text = player.status;
            
            
            panel8.Visible = false;
            panel6.Visible = false;
            
        }

        private void button15_Click(object sender, EventArgs e)
        {
            button4.Visible = false;
            button5.Visible = false;
            label1.Text = player.status;
            
            
            
            panel8.Visible = false;
            panel6.Visible = false;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.instagram.com/salihbakia/");
        }

        private void button20_Click(object sender, EventArgs e)
        {
            
            player.Ctlcontrols.pause();


        }

        private void button19_Click(object sender, EventArgs e)
        {
            
            player.Ctlcontrols.play();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
           

            if (listBox1.SelectedIndex < listBox1.Items.Count - 1)//listboxta 1den fazla item varsa.
            {
                listBox1.SelectedIndex++;//Sonraki iteme geçmek.
                player.URL = listBox1.SelectedItem.ToString();//MediaPlayer URLsi.
                
            }

        }

        private void player_Enter(object sender, EventArgs e)
        {

        }

        private void player_PlayStateChange(object sender, AxWMPLib._WMPOCXEvents_PlayStateChangeEvent e)
        {
            
            label1.Text = player.status;

            
        }

        private void button23_Click(object sender, EventArgs e)
        {
            
        }

        private void button24_Click(object sender, EventArgs e)
        {
            panel8.Visible = true;
            panel6.Visible = false;
            
            
        }

        private void button25_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();

            for (int i = 0; i < openFileDialog1.SafeFileNames.Length; i++)
            {
                listBox1.Items.Add(openFileDialog1.SafeFileNames[i].ToString());
                listBox2.Items.Add(openFileDialog1.FileNames[i].ToString());
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox2.SelectedIndex = listBox1.SelectedIndex;
            player.URL = listBox2.SelectedItem.ToString();
            if(listBox1.SelectedIndex == 0)
            {
                
            }

            if (listBox1.SelectedIndex > 0)
            {
               
            }
            player.Ctlcontrols.play();
            

        }

        private void button22_Click(object sender, EventArgs e)
        {
            player.Ctlcontrols.stop();
           
        }

        private void button26_Click(object sender, EventArgs e)
        {
            panel6.Visible = true;
            panel8.Visible =false;
        }

        private void button28_Click(object sender, EventArgs e)
        {
            player.URL = "http://45.32.154.169:9300/;";
            player.Ctlcontrols.play();
        }

        private void button29_Click(object sender, EventArgs e)
        {
            player.URL = "http://46.20.3.204:80/";
            player.Ctlcontrols.play();
        }

        private void button30_Click(object sender, EventArgs e)
        {
            player.URL = "http://46.20.3.201:80/";
            player.Ctlcontrols.play();
        }

        private void button31_Click(object sender, EventArgs e)
        {
            player.URL = "http://37.247.98.8/stream/166/";
            player.Ctlcontrols.play();
        }

        private void button32_Click(object sender, EventArgs e)
        {
            player.URL = "https://playerservices.streamtheworld.com/api/livestream-redirect/VIRGIN_RADIO_SC?/;";
            player.Ctlcontrols.play();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            label1.Text = player.status;
        }

        private void button21_Click(object sender, EventArgs e)
        {
            listBox2.SelectedIndex = listBox1.SelectedIndex;
            player.URL = listBox2.SelectedItem.ToString();
            listBox1.SelectedIndex++;//Sonraki iteme geçmek.
            player.URL = listBox1.SelectedItem.ToString();//MediaPlayer URLsi.
            
            
        }

        private void button18_Click(object sender, EventArgs e)
        {
            listBox1.SelectedIndex--;//Sonraki iteme geçmek.
            player.Ctlcontrols.play();
            player.URL = listBox1.SelectedItem.ToString();//MediaPlayer URLsi
            player.Ctlcontrols.play();
            
            
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
        }

        private void listBox3_Click(object sender, EventArgs e)
        {
            
        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            player.URL = listBox1.SelectedItem.ToString();
            player.Ctlcontrols.play();
        }

        private void listBox6_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox6_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            
            player.URL = listBox1.SelectedItem.ToString();
            player.Ctlcontrols.play();
        }

        private void listBox8_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            player.URL = listBox1.SelectedItem.ToString();
            player.Ctlcontrols.play();
        }

        private void button13_Click_1(object sender, EventArgs e)
        {
            
        }

        private void button33_Click(object sender, EventArgs e)
        {
            
            
        }

        private void button34_Click(object sender, EventArgs e)
        {
            
            
        }

        private void button39_Click(object sender, EventArgs e)
        {
            player.URL = "https://playerservices.streamtheworld.com/api/livestream-redirect/JOY_TURK_SC?/;";
        }

        private void button38_Click(object sender, EventArgs e)
        {
            player.URL = "https://ssl.radyopanel.com:7001/";
        }

        private void button37_Click(object sender, EventArgs e)
        {
            player.URL = " http://46.20.7.126/bestfmmp3";
        }

        private void button36_Click(object sender, EventArgs e)
        {
            player.URL = "https://playerservices.streamtheworld.com/api/livestream-redirect/METRO_FM_SC?/;";
        }

        private void button35_Click(object sender, EventArgs e)
        {
            player.URL = "https://radyo.duhnet.tv/slowturk";
        }

        private void button44_Click(object sender, EventArgs e)
        {
            player.URL = "http://46.20.3.251/stream/169/";
        }

        private void button43_Click(object sender, EventArgs e)
        {
            player.URL = "https://listen.radyofenomen.com/fenomen/128/icecast.audio";
        }

        private void button42_Click(object sender, EventArgs e)
        {
            player.URL = "http://yayin.turkhosted.com:6056/;";
        }

        private void button41_Click(object sender, EventArgs e)
        {
            player.URL = "http://radyo.yayin.com.tr:6134/;";
        }

        private void button40_Click(object sender, EventArgs e)
        {
            player.URL = " http://162.254.207.45:9994/;";
        }

        private void button49_Click(object sender, EventArgs e)
        {
            player.URL = "https://radyo.duhnet.tv/cnnturk";
        }

        private void button48_Click(object sender, EventArgs e)
        {
            player.URL = "http://ntvrdwmp.radyotvonline.com/;";
        }

        private void button47_Click(object sender, EventArgs e)
        {
            player.URL = "http://radyo.turkuradyo.net:4591/;";
        }

        private void button46_Click(object sender, EventArgs e)
        {
            player.URL = " http://yayin.yayindakiler.com:4112/;";
        }

        private void button45_Click(object sender, EventArgs e)
        {
            player.URL = "https://n10101m.mediatriple.net/numberone90s";
        }

        private void imgVisualize_Click(object sender, EventArgs e)
        {

        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://twitter.com/zyetsa");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://github.com/zyetsa");
        }

        private void button16_Click(object sender, EventArgs e)
        {
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form2 ff = new Form2();
            ff.Show();
        }
    }
}
